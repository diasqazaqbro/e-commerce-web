"use strict";
exports.id = 143;
exports.ids = [143];
exports.modules = {

/***/ 1298:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ FiltrationProduct)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9648);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_1__]);
axios__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



function FiltrationProduct({ products , categoryProps , setProperties  }) {
    const [categoryState, setCategoryState] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)("");
    const [state, setState] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)("");
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{
        axios__WEBPACK_IMPORTED_MODULE_1__["default"].post("/api/category").then((response)=>{
            setCategoryState(response.data);
        });
    }, []);
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{
        setProperties(state);
    }, [
        state
    ]);
    const checkFluency = (v)=>{
        let check = document.querySelector("#" + v);
        let f = document.forms.Form;
        f.onchange = function() {
            var n = f.querySelectorAll('[type="checkbox"]'), l = f.querySelectorAll('[type="checkbox"]:checked');
            for(var j = 0; j < n.length; j++)if (l.length >= 1) {
                n[j].disabled = true;
                for(var i = 0; i < l.length; i++)l[i].disabled = false;
            } else {
                n[j].disabled = false;
            }
        };
        if (check.checked === true) {
            setState(v);
        } else {
            setState("");
        }
    };
    const filtrationCategory = categoryState.length && categoryState.filter((f)=>f._id === categoryProps);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            filtrationCategory.length && filtrationCategory[0].properties.map((p, index)=>{
                return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "item",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                            className: "mt-3",
                            children: p.name
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("form", {
                            name: "Form",
                            children: p.values.map((v)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "custom-checkbox",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                            id: v,
                                            onClick: ()=>checkFluency(v),
                                            type: "checkbox"
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("label", {
                                            for: v,
                                            children: [
                                                v,
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {})
                                            ]
                                        })
                                    ]
                                }, v))
                        })
                    ]
                }, index);
            }),
            state
        ]
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2688:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ ProductInner)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _FiltrationProduct__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1298);
/* harmony import */ var _ProductBox__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4122);
/* harmony import */ var _SelectFiltration__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8474);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_FiltrationProduct__WEBPACK_IMPORTED_MODULE_2__]);
_FiltrationProduct__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];





function ProductInner({ products , category  }) {
    const filterProduct = products.filter((f)=>f.category === category);
    const [currentProperties, setCurrentProperties] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [productsArr, setProductsArr] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(products);
    const setProperties = (value)=>{
        setCurrentProperties(value);
    };
    const [selectedSort, setSelectedSort] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const sortPosts = (sort)=>{
        setSelectedSort(sort);
        if (sort === "title") {
            setProductsArr([
                ...productsArr
            ].sort((a, b)=>{
                if (a.title < b.title) {
                    return -1;
                }
                if (a.title > b.title) {
                    return 1;
                }
                return 0;
            }));
        } else if (sort === "priceLow") {
            setProductsArr([
                ...productsArr
            ].sort((a, b)=>{
                if (a.price < b.price) {
                    return -1;
                }
                if (a.price > b.price) {
                    return 1;
                }
                return 0;
            }));
        } else if (sort === "priceHight") {
            setProductsArr([
                ...productsArr
            ].sort((a, b)=>{
                if (a.price < b.price) {
                    return -1;
                }
                if (a.price > b.price) {
                    return 1;
                }
                return 0;
            }).reverse());
        } else if (sort === "createdAt") {
            setProductsArr([
                ...productsArr
            ].reverse());
        }
        console.log(productsArr);
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "row",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "col-md-4 col-sm-12 filtration",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_SelectFiltration__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                        value: selectedSort,
                        onChange: sortPosts,
                        defaultValue: "Сортировка",
                        options: [
                            {
                                value: "title",
                                name: "По названию"
                            },
                            {
                                value: "priceLow",
                                name: "По цене (Сначала дешевые)"
                            },
                            {
                                value: "priceHight",
                                name: "По цене (Сначала дорогие)"
                            },
                            {
                                value: "createdAt",
                                name: "По дате"
                            }
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_FiltrationProduct__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                        setProperties: setProperties,
                        categoryProps: category,
                        productsArr: filterProduct
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "col-md-7 col-12-sm",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "row",
                    children: productsArr?.length > 0 && productsArr.filter((f)=>f.category === category).filter((f)=>!currentProperties ? f : f.properties.Производитель == currentProperties).map((product)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ProductBox__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                            col: "4",
                            ...product
                        }, product._id))
                })
            })
        ]
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8116:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ NavProduct)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_1__);


function NavProduct({ nav  }) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("nav", {
        style: {
            "--bs-breadcrumb-divider": "'>';"
        },
        "aria-label": "breadcrumb",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ol", {
            className: "breadcrumb",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                    className: "breadcrumb-item",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                        href: "/",
                        children: "Главная страница"
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                    className: "breadcrumb-item active",
                    "aria-current": "page",
                    children: nav
                })
            ]
        })
    });
}


/***/ }),

/***/ 8474:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ SelectFiltration)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);

function SelectFiltration({ options , defaultValue , value , onChange  }) {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("select", {
        className: "select-profession",
        value: value,
        onChange: (event)=>onChange(event.target.value),
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                disabled: true,
                value: "",
                children: defaultValue
            }),
            options.map((o)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                    value: o.value,
                    children: o.name
                }, o.value))
        ]
    });
}


/***/ })

};
;